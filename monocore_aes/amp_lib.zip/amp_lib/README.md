# amp_lib
Repository for the Asymetric Multi Processing SoC
